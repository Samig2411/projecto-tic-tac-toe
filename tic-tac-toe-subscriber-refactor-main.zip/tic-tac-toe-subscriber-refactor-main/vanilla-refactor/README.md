There are two branches for this example:

- `main` - contains the Vanilla ES6 refactor (no build steps, no dependencies)
- `typescript` - contains the same exact implementation, but using TypeScript (has dependencies and a build step)
