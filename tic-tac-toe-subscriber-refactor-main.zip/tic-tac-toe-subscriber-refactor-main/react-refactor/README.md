## Run project

```
yarn install
yarn dev
```
